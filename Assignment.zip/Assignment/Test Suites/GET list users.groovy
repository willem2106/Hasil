import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

RequestObject request = findTestObject('Object Repository/API/GET_ListUsers')

ResponseObject response = WS.sendRequest(request)

// Tambahkan langkah verifikasi respons jika diperlukan